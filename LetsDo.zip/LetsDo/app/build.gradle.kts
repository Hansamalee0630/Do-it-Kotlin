plugins {
    alias(libs.plugins.androidApplication)
    id("org.jetbrains.kotlin.android")
    //id("androidx.room")
    id("kotlin-kapt")
    id("kotlin-android")

}

android {
    namespace = "com.example.letsdo"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.letsdo"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        dataBinding = true
        aidl = false
        renderScript = false
        shaders = false
        buildConfig = true
        resValues = true
        mlModelBinding = true
    }

    kapt {
        arguments {
            arg("jvmTarget", "1.8")
        }
    }
}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    implementation("androidx.core:core-ktx:1.13.1")
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
    implementation("androidx.room:room-ktx:2.6.0")
    implementation ("androidx.room:room-runtime:2.4.3")
    annotationProcessor ("androidx.room:room-compiler:2.4.3")
}